import { Link } from "react-router-dom"
import { FaUserShield } from "react-icons/fa";
import { AiOutlineSwapRight } from "react-icons/ai";
import { BsFillShieldLockFill } from "react-icons/bs";
import video from '../../assets/Video1/video.mp4'

import '../../App.css'
import '../../Styles/SignupLogin/Login.css'

const Login = () => {
  return (
    <div className="loginPage flex">
      <div className="container flex">
        <div className="videoDiv">
            <video src={video} autoPlay muted loop></video>
            <div className="textDiv">
              <h2 className="title">
                  World class barber shop
              </h2>
            </div>
            <div className="footerDiv flex">
              <span className="text">Don't have an account?</span>
              <Link to='/signup'>
                <button className="btn">Signup</button>
              </Link>
            </div>
        </div>
        <div className="formDiv flex">
          <div className="headerDiv">
            <h3>Welcome back!</h3>
          </div>
          <form action="" className="form-grid">
            <div className="inputDiv">
              <label htmlFor="email">Email</label>
              <div className="input flex">
              <FaUserShield className="icon" />
              <input type="email" name="email" id="email"placeholder="Enter your email" required/>
              </div>
            </div>
            <div className="inputDiv">
              <label htmlFor="password">Password</label>
              <div className="input flex">
              <BsFillShieldLockFill className="icon" />
              <input type="password" name="password" id="password"placeholder="Enter your password" required/>
              </div>
            </div>
            <button type="submit" className="btn flex">
              <span>Login</span>
              <AiOutlineSwapRight className="icon" />
            </button>
            <span className="forgotPassword">
              Forgot your password? <a href="">Click here</a>
            </span>
          </form>
        </div>
      </div>
    </div>
  )
}

export default Login

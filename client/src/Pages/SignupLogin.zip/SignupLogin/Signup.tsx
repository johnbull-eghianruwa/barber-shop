import { Link } from "react-router-dom";
import { FaUserShield } from "react-icons/fa";
import { AiOutlineSwapRight } from "react-icons/ai";
import { BsFillShieldLockFill } from "react-icons/bs";
import video from '../../assets/Video1/video.mp4';
import { useNavigate } from "react-router-dom";
import '../../App.css';
import '../../Styles/SignupLogin/Login.css';
import { FC, useState } from "react";

interface SignProps{
  name: string
  email: string
  password: string
}

const Signup: FC<SignProps> = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const navgate = useNavigate();

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    try {
      const response = await fetch('http://localhost:3001/api/v2/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name,
          email,
          password,
          
        }),
      });
      if (response.ok) {
        setMessage('User has been created');
        // Clear the form fields
        setName('');
        setEmail('');
        setPassword('');
      } else {
        setMessage('Failed to create user');
      }
    } catch (error) {
      setMessage('Error: ' + error.message);
      console.error('Error:', error);
      navgate('/login')
    }
  };

  return (
    <div className="signupPage flex">
      <div className="container flex">
        <div className="videoDiv">
          <video src={video} autoPlay muted loop></video>
          <div className="textDiv">
            <h2 className="title">
              World class barber shop
            </h2>
          </div>
          <div className="footerDiv flex">
            <span className="text">You have an account?</span>
            <Link to='/login'>
              <button className="btn">Login</button>
            </Link>
          </div>
        </div>
        <div className="formDiv flex">
          <div className="headerDiv">
            <h3>Welcome back!</h3>
          </div>
          <form className="form-grid" onSubmit={handleSubmit}>
            <div className="inputDiv">
              <label htmlFor="name">Name</label>
              <div className="input flex">
                <FaUserShield className="icon" />
                <input
                  type="text"
                  name="name"
                  id="name"
                  placeholder="Enter your name"
                  value={name}
                  autoComplete="name"
                  onChange={(event) => setName(event.target.value)}
                  required 
                />
              </div>
            </div>
            <div className="inputDiv">
              <label htmlFor="email">Email</label>
              <div className="input flex">
                <FaUserShield className="icon" />
                <input
                  type="email"
                  name="email"
                  id="email"
                  placeholder="Enter your email"
                  value={email}
                  autoComplete="email"
                  onChange={(event) => setEmail(event.target.value)}
                  required
                />
              </div>
            </div>
            <div className="inputDiv">
              <label htmlFor="password">Password</label>
              <div className="input flex">
                <BsFillShieldLockFill className="icon" />
                <input
                  type="password"
                  name="password"
                  id="password"
                  placeholder="Enter your password"
                  value={password}
                  autoComplete="new-password"
                  onChange={(event) => setPassword(event.target.value)}
                  required 
                />
              </div>
            </div>
            <button type="submit" className="btn flex">
              <span>Sign up</span>
              <AiOutlineSwapRight className="icon" />
            </button>
            <span className="forgotPassword">
              Forgot your password? <a href="">Click here</a>
            </span>
          </form>
          {message && <div className="message">{message}</div>}
        </div>
      </div>
    </div>
  );
};

export default Signup;
